

NEIGHBORS = [
    (-1, 0),  # up
    (0, 1),  # right
    (1, 0),  # down
    (0, -1),  # left
    (-1, 1),  # dur
    (1, 1),  # ddr
    (1, -1),  # ddl
    (-1, -1)  # dul
]


FOUNT_MAX_FOR_WORD = 'FOUNT_MAX_FOR_WORD'